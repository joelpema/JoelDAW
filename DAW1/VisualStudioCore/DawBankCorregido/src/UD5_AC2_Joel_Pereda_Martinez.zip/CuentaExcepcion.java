public class CuentaExcepcion extends Exception{

    public CuentaExcepcion (String mensaje){
        super(mensaje);
    }

}
