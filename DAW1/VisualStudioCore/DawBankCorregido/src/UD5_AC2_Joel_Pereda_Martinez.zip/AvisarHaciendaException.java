public class AvisarHaciendaException extends Exception{

    public AvisarHaciendaException (String mensaje){
        super(mensaje);
    }

}
