public enum Tipo {
    Ingreso, Retirada;
}
