public enum Genero_Videojuegos {
ARPG, MMO, SHOOTER, PLATAFORMAS
}
