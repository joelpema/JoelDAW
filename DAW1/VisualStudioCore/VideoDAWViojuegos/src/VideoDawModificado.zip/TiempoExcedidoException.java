public class TiempoExcedidoException extends Exception {
    public TiempoExcedidoException(String mensaje) {
        super(mensaje);
    }
}