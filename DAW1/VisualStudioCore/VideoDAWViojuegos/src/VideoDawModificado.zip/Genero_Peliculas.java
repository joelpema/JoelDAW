public enum Genero_Peliculas {
CIENCIA_FICCION, FANTASIA, TERROR, COMEDIA
}
