public class ArticuloAlquilado extends Exception {
    public ArticuloAlquilado(String mensaje) {
        super(mensaje);
    }
}