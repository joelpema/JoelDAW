import discord
from discord.ext import commands
from dotenv import load_dotenv
import asyncio
import os

# ==========================================
# CONFIGURACIÓN
# ==========================================

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(
    command_prefix="!",
    intents=intents
)

# Importar motor de dados
from dice import roll_pool, all_image_names
from render import render_pool, missing_images, IMAGES_DIR


# ==========================================
# EVENTOS
# ==========================================

@bot.event
async def on_ready():
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"🎲 Bot conectado: {bot.user}")
    print("⚔️ Sistema Genesys RPG preparado")
    missing = missing_images(all_image_names())
    if missing:
        print(f"⚠️ Faltan {len(missing)} de {len(all_image_names())} imágenes en {IMAGES_DIR}:")
        for item in missing:
            print(f"   - {item}")


# ==========================================
# RESUMEN DE LA TIRADA
# ==========================================

def _count(n, singular, plural):
    return f"{n} {singular if n == 1 else plural}"


def build_summary(totals, net_success, net_advantage):
    """Ej.: '4 Éxitos • 1 Ventaja • 1 Triunfo'"""
    parts = []

    if net_success > 0:
        parts.append(_count(net_success, "Éxito", "Éxitos"))
    elif net_success < 0:
        parts.append(_count(abs(net_success), "Fallo", "Fallos"))

    if net_advantage > 0:
        parts.append(_count(net_advantage, "Ventaja", "Ventajas"))
    elif net_advantage < 0:
        parts.append(_count(abs(net_advantage), "Amenaza", "Amenazas"))

    if totals["triumph"] > 0:
        parts.append(_count(totals["triumph"], "Triunfo", "Triunfos"))
    if totals["despair"] > 0:
        parts.append(_count(totals["despair"], "Desesperación", "Desesperaciones"))

    if not parts:
        return "Sin resultado neto (todo se cancela o salió vacío)"
    return " • ".join(parts)


# ==========================================
# COMANDO DE TIRADAS
# ==========================================

@bot.command(name="roll")
async def roll(ctx, *, pool: str = None):

    if not pool:
        # Embed de ayuda cuando no se especifican dados
        embed_help = discord.Embed(
            title="🎲 Ayuda de Tiradas - Genesys RPG",
            description="¡Necesitas indicar qué dados quieres lanzar!\n\n**Ejemplo:**\n`!roll yyggkkrr`",
            color=discord.Color.blue()
        )
        embed_help.add_field(
            name="Dados Disponibles",
            value=(
                "🔵 `b` — Bonus\n"
                "🟢 `g` — Habilidad\n"
                "🟡 `y` — Competencia\n"
                "⚫ `k` — Desventaja\n"
                "🟣 `p` — Dificultad\n"
                "🔴 `r` — Desafío"
            ),
            inline=False
        )
        await ctx.send(embed=embed_help)
        return

    try:
        result = roll_pool(pool)

        net_success = result["net_success"]
        net_advantage = result["net_advantage"]
        totals = result["totals"]

        # Color de la barra lateral según prioridad temática:
        # Desesperación > Triunfo > Éxito neto > Fallo neto > Ventajas > Amenazas > neutro
        if totals["despair"] > 0:
            embed_color = discord.Color.purple()
        elif totals["triumph"] > 0:
            embed_color = discord.Color.gold()
        elif net_success > 0:
            embed_color = discord.Color.green()
        elif net_success < 0:
            embed_color = discord.Color.red()
        elif net_advantage > 0:
            embed_color = discord.Color.blue()
        elif net_advantage < 0:
            embed_color = discord.Color.orange()
        else:
            embed_color = discord.Color.from_rgb(139, 69, 19)  # marrón neutro

        # Imagen con los dados (Pillow), generada fuera del bucle de eventos
        image_buffer = await asyncio.to_thread(render_pool, result["dice"])
        image_file = discord.File(image_buffer, filename="tirada.png")

        # Embed 1: título + imagen de los dados
        embed_dice = discord.Embed(
            title=f"{ctx.author.display_name} tira los dados",
            color=embed_color
        )
        embed_dice.set_image(url="attachment://tirada.png")

        # Embed 2: resumen en una línea
        embed_summary = discord.Embed(
            description=build_summary(totals, net_success, net_advantage),
            color=embed_color
        )
        avatar_url = ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
        embed_summary.set_footer(
            text=f"Solicitado por {ctx.author.display_name}",
            icon_url=avatar_url
        )

        await ctx.send(embeds=[embed_dice, embed_summary], file=image_file)

    except ValueError as error:
        await ctx.send(f"❌ **Error en la tirada:** {error}")


# ==========================================
# INICIAR BOT
# ==========================================

if not TOKEN:
    raise ValueError(
        "❌ No se ha encontrado DISCORD_TOKEN en el archivo .env"
    )

bot.run(TOKEN)