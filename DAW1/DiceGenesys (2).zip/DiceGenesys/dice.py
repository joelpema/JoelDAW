import random

# ==================================================
# CONFIGURACIÓN DE LOS DADOS GENESYS
# ==================================================
# Cada cara se representa mediante la tupla:
# (éxitos, fallos, ventajas, amenazas, triunfos, desesperaciones)
# ==================================================
DICE = {
    "b": {
        "name": "Bonus",
        "color": "🔵",
        "faces": [
            (0, 0, 0, 0, 0, 0),  # Vacía (33.33%)
            (0, 0, 0, 0, 0, 0),  # Vacía (33.33%)
            (1, 0, 0, 0, 0, 0),  # Éxito (16.67%)
            (0, 0, 1, 0, 0, 0),  # Ventaja (16.67%)
            (0, 0, 2, 0, 0, 0),  # Doble Ventaja (16.67%)
            (1, 0, 1, 0, 0, 0),  # Éxito + Ventaja (16.67%)
        ],
    },
    "g": {
        "name": "Habilidad",
        "color": "🟢",
        "faces": [
            (0, 0, 0, 0, 0, 0),  # Vacía (12.5%)
            (1, 0, 0, 0, 0, 0),  # Éxito (25%)
            (1, 0, 0, 0, 0, 0),  # Éxito (25%)
            (2, 0, 0, 0, 0, 0),  # Doble Éxito (12.5%)
            (0, 0, 1, 0, 0, 0),  # Ventaja (25%)
            (0, 0, 1, 0, 0, 0),  # Ventaja (25%)
            (1, 0, 1, 0, 0, 0),  # Éxito + Ventaja (12.5%)
            (0, 0, 2, 0, 0, 0),  # Doble Ventaja (12.5%)
        ],
    },
    "y": {
        "name": "Competencia",
        "color": "🟡",
        "faces": [
            (0, 0, 0, 0, 0, 0),  # Vacía (8.33%)
            (1, 0, 0, 0, 0, 0),  # Éxito (16.67%)
            (1, 0, 0, 0, 0, 0),  # Éxito (16.67%)
            (2, 0, 0, 0, 0, 0),  # Doble Éxito (25%)
            (2, 0, 0, 0, 0, 0),  # Doble Éxito (25%)
            (0, 0, 1, 0, 0, 0),  # Ventaja (8.33%)
            (1, 0, 1, 0, 0, 0),  # Éxito + Ventaja (25%)
            (1, 0, 1, 0, 0, 0),  # Éxito + Ventaja (25%)
            (1, 0, 1, 0, 0, 0),  # Éxito + Ventaja (25%)
            (0, 0, 2, 0, 0, 0),  # Doble Ventaja (16.67%)
            (0, 0, 2, 0, 0, 0),  # Doble Ventaja (16.67%)
            (0, 0, 0, 0, 1, 0),  # Triunfo (8.33%)
        ],
    },
    "k": {
        "name": "Desventaja",
        "color": "⚫",
        "faces": [
            (0, 0, 0, 0, 0, 0),  # Vacía (33.33%)
            (0, 0, 0, 0, 0, 0),  # Vacía (33.33%)
            (0, 1, 0, 0, 0, 0),  # Fallo (33.33%)
            (0, 1, 0, 0, 0, 0),  # Fallo (33.33%)
            (0, 0, 0, 1, 0, 0),  # Amenaza (33.33%)
            (0, 0, 0, 1, 0, 0),  # Amenaza (33.33%)
        ],
    },
    "p": {
        "name": "Dificultad",
        "color": "🟣",
        "faces": [
            (0, 0, 0, 0, 0, 0),  # Vacía (12.5%)
            (0, 1, 0, 0, 0, 0),  # Fallo (12.5%)
            (0, 2, 0, 0, 0, 0),  # Doble Fallo (12.5%)
            (0, 0, 0, 1, 0, 0),  # Amenaza (37.5%)
            (0, 0, 0, 1, 0, 0),  # Amenaza (37.5%)
            (0, 0, 0, 1, 0, 0),  # Amenaza (37.5%)
            (0, 0, 0, 2, 0, 0),  # Doble Amenaza (12.5%)
            (0, 1, 0, 1, 0, 0),  # Fallo + Amenaza (12.5%)
        ],
    },
    "r": {
        "name": "Desafío",
        "color": "🔴",
        "faces": [
            (0, 0, 0, 0, 0, 0),  # Vacía (8.33%)
            (0, 1, 0, 0, 0, 0),  # Fallo (16.67%)
            (0, 1, 0, 0, 0, 0),  # Fallo (16.67%)
            (0, 2, 0, 0, 0, 0),  # Doble Fallo (16.67%)
            (0, 2, 0, 0, 0, 0),  # Doble Fallo (16.67%)
            (0, 0, 0, 1, 0, 0),  # Amenaza (16.67%)
            (0, 0, 0, 1, 0, 0),  # Amenaza (16.67%)
            (0, 1, 0, 1, 0, 0),  # Fallo + Amenaza (16.67%)
            (0, 1, 0, 1, 0, 0),  # Fallo + Amenaza (16.67%)
            (0, 0, 0, 2, 0, 0),  # Doble Amenaza (16.67%)
            (0, 0, 0, 2, 0, 0),  # Doble Amenaza (16.67%)
            (0, 0, 0, 0, 0, 1),  # Desesperación (8.33%)
        ],
    },
}

SYMBOLS = {
    "success": ":white_check_mark:",
    "failure": ":x:",
    "advantage": ":arrow_up:",
    "threat": ":warning:",
    "triumph": ":trident:",
    "despair": ":fleur_de_lis:",
}

# Máximo de dados por tirada (evita imágenes gigantes y abusos)
MAX_DICE = 30


def face_slug(face):
    """
    Convierte una cara (tupla de 6 valores) en un nombre de archivo estable.
    Ejemplos: "blank", "success", "success2", "advantage", "success_advantage",
              "failure_threat", "triumph", "despair"
    """
    success, failure, advantage, threat, triumph, despair = face
    parts = []
    for name, amount in (
        ("success", success),
        ("failure", failure),
        ("advantage", advantage),
        ("threat", threat),
        ("triumph", triumph),
        ("despair", despair),
    ):
        if amount:
            parts.append(name if amount == 1 else f"{name}{amount}")
    return "_".join(parts) if parts else "blank"


def all_image_names():
    """Lista de todos los nombres de imagen esperados (sin extensión)."""
    names = []
    for letter, die in DICE.items():
        for slug in dict.fromkeys(face_slug(f) for f in die["faces"]):
            names.append(f"{letter}_{slug}")
    return names


def roll_pool(pool):
    pool = pool.lower().replace(" ", "")
    if not pool:
        raise ValueError("Debes indicar al menos un dado.")
    if len(pool) > MAX_DICE:
        raise ValueError(f"Máximo {MAX_DICE} dados por tirada.")
    for letter in pool:
        if letter not in DICE:
            raise ValueError(f"Dado desconocido: '{letter}'")

    totals = {
        "success": 0,
        "failure": 0,
        "advantage": 0,
        "threat": 0,
        "triumph": 0,
        "despair": 0,
    }
    results = []
    for letter in pool:
        die = DICE[letter]
        face = random.choice(die["faces"])
        names = list(totals.keys())
        for name, amount in zip(names, face):
            totals[name] += amount
        symbols = [
            f"{SYMBOLS[name]} ×{amount}"
            for name, amount in zip(names, face)
            if amount > 0
        ]
        results.append({
            "letter": letter,            # b, g, y, k, p, r
            "face": face_slug(face),     # p. ej. "success_advantage"
            "name": die["name"],
            "color": die["color"],
            "symbols": symbols,
            "blank": not symbols,
        })

    net_success = (
        totals["success"]
        + totals["triumph"]
        - totals["failure"]
        - totals["despair"]
    )
    net_advantage = (
        totals["advantage"]
        - totals["threat"]
    )
    return {
        "dice": results,
        "totals": totals,
        "net_success": net_success,
        "net_advantage": net_advantage,
    }
