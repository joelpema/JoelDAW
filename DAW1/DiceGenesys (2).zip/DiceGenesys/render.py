from io import BytesIO
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps

# ==========================================
# CONFIGURACIÓN DE LA IMAGEN
# ==========================================

# Carpeta con las imágenes de las caras (junto a este archivo)
IMAGES_DIR = Path(__file__).parent / "images"

TILE = 72        # tamaño (px) de la celda de cada dado
GAP = 8          # separación entre dados (px)
COLUMNS = 6      # dados por fila antes de saltar de línea
EXTENSIONS = (".png", ".webp", ".gif", ".jpg", ".jpeg")

# ==========================================
# NOMBRES DE ARCHIVO (pack "genesys-*")
# ==========================================
# Formato: genesys-<color><código>
#   código = s (éxito), a (ventaja), f (fallo), t (amenaza), en ese orden
#   ejemplos: genesys-green (vacía), genesys-greensa (éxito+ventaja),
#             genesys-purpleff (doble fallo), genesys-redft (fallo+amenaza)
COLORS = {
    "b": "blue",
    "g": "green",
    "y": "yellow",
    "k": "black",
    "p": "purple",
    "r": "red",
}

# Cualquier cara cuyo nombre no siga la regla se puede forzar aquí:
#   "y_triumph": "genesys-nombre_real",
OVERRIDES = {}


def _candidates(letter, face):
    """Posibles nombres de archivo (sin extensión) para una cara, por orden de prioridad."""
    key = f"{letter}_{face}"
    if key in OVERRIDES:
        return [OVERRIDES[key]]

    base = f"genesys-{COLORS[letter]}"
    if face == "blank":
        return [base]
    if face == "triumph":
        return [base + "t", base + "triumph", base + "tr", base + "r"]
    if face == "despair":
        return [base + "d", base + "despair", base + "de"]

    code = ""
    for word, symbol in (("success", "s"), ("advantage", "a"), ("failure", "f"), ("threat", "t")):
        if word in face:
            # "success2" -> 2 veces; "success" -> 1 vez
            part = next(p for p in face.split("_") if p.startswith(word))
            n = int(part[len(word):] or 1)
            code += symbol * n
    return [base + code]


def find_image(letter, face):
    """Devuelve la ruta de la imagen de una cara, o None si no existe."""
    for name in _candidates(letter, face):
        for ext in EXTENSIONS:
            path = IMAGES_DIR / f"{name}{ext}"
            if path.exists():
                return path
    return None


def missing_images(all_names):
    """all_names: lista de 'dado_cara' (dice.all_image_names())."""
    missing = []
    for key in all_names:
        letter, _, face = key.partition("_")
        if find_image(letter, face) is None:
            missing.append(f"{key} -> {_candidates(letter, face)[0]}")
    return missing


_cache = {}
_missing = set()


def _placeholder(key):
    """Cuadrado gris con el nombre esperado, para cuando falta la imagen."""
    img = Image.new("RGBA", (TILE, TILE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle(
        (2, 2, TILE - 3, TILE - 3), radius=10,
        fill=(70, 70, 78, 255), outline=(150, 150, 160, 255), width=2,
    )
    letter, _, face = key.partition("_")
    draw.text((8, 8), letter.upper(), fill=(255, 255, 255, 255))
    draw.text((8, 26), face.replace("_", "\n"), fill=(220, 220, 230, 255))
    return img


def _load(letter, face):
    """Carga (y cachea) la imagen de una cara."""
    key = f"{letter}_{face}"
    if key in _cache:
        return _cache[key]

    path = find_image(letter, face)
    if path is not None:
        img = Image.open(path).convert("RGBA")
        img = ImageOps.contain(img, (TILE, TILE), Image.LANCZOS)
    else:
        if key not in _missing:
            _missing.add(key)
            print(f"⚠️ Falta la imagen de {key}: {IMAGES_DIR / (_candidates(letter, face)[0] + '.png')}")
        img = _placeholder(key)

    _cache[key] = img
    return img


def render_pool(dice):
    """
    Recibe la lista result["dice"] de roll_pool y devuelve un PNG (BytesIO)
    con todos los dados en cuadrícula, en el orden en que se tiraron.
    """
    count = len(dice)
    columns = min(COLUMNS, count)
    rows = -(-count // COLUMNS)  # división hacia arriba

    width = columns * TILE + (columns - 1) * GAP
    height = rows * TILE + (rows - 1) * GAP
    canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))

    for index, die in enumerate(dice):
        img = _load(die["letter"], die["face"])
        col, row = index % COLUMNS, index // COLUMNS
        x = col * (TILE + GAP) + (TILE - img.width) // 2
        y = row * (TILE + GAP) + (TILE - img.height) // 2
        canvas.paste(img, (x, y), img)

    buffer = BytesIO()
    canvas.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer
