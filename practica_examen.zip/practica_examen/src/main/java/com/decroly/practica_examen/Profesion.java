package com.decroly.practica_examen;

public enum Profesion {
    Profesor,
    Alumno
}
