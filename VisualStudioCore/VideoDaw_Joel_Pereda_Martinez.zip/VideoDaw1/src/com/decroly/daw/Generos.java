package com.decroly.daw;

public enum Generos {
    ACCION, ANIME, COMEDIA, DRAMA, FANTASIA, TERROR, DOCUMENTALES;
    
}