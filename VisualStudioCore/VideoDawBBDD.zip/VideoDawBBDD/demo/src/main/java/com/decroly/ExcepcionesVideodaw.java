package com.decroly;

public class ExcepcionesVideodaw extends Exception{
    public ExcepcionesVideodaw(String mensaje){
        super(mensaje);
    }
}
