package com;

public enum Generos {
    ACCION, COMEDIA, DRAMA, FANTASIA, TERROR, DOCUMENTALES;
    
}

