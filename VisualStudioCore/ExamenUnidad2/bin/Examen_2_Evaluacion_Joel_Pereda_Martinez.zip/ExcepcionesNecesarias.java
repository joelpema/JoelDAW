public class ExcepcionesNecesarias extends Exception{

    public class ClienteYaRegistradoException extends Exception {
        public ClienteYaRegistradoException(String mensaje) {
            super(mensaje);
        }
    }
    
    


}
