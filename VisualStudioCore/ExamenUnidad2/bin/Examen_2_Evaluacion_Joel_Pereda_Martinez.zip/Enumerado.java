public enum Enumerado {
    Informática, Gestión, Marketing
}
