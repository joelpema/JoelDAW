public abstract class Contacto {
    protected String nombre;
    protected String telefono;

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }
}