package com.example.meteodaw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeteodawApplicationTests {

	@Test
	void contextLoads() {
	}

}
