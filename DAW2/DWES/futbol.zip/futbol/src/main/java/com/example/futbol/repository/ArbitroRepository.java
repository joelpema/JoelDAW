package com.example.futbol.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.futbol.entity.Arbitro;
public interface ArbitroRepository extends JpaRepository<Arbitro, Long> {

    
}