package com.example.footballapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballappApplicationTests {

	@Test
	void contextLoads() {
	}

}
