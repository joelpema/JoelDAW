package com.example.GestionPistas;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
// Esta anotación marca el punto de inicio de la aplicación Spring Boot.
@SpringBootApplication
public class GestionPistasApplication {
public static void main(String[] args) {
// Este método inicia la aplicación Spring Boot.
SpringApplication.run(GestionPistasApplication.class, args);
}
}
