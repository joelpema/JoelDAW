export interface ProductoInterface {

    sku: string,
    title: string,
    price: string

}
