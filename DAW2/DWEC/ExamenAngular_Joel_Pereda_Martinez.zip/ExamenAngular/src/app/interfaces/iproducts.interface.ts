export interface Iproducts {

    id: number,
    name: string,
    description: string,
    price: number,
    category: string,
    image: string,
    active: boolean


}
