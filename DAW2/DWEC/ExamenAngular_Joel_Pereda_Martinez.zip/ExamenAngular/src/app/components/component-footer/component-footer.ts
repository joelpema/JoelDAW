import { Component } from '@angular/core';

@Component({
  selector: 'app-component-footer',
  imports: [],
  templateUrl: './component-footer.html',
  styleUrl: './component-footer.css',
})
export class ComponentFooter {

}
