import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-component-home',
  imports: [RouterLink],
  templateUrl: './component-home.html',
  styleUrl: './component-home.css',
})
export class ComponentHome {

}
