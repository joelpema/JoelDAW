import { Component } from '@angular/core';

@Component({
  selector: 'app-landin-page',
  imports: [],
  templateUrl: './landin-page.html',
  styleUrl: './landin-page.css',
})
export class LandinPage {

}
