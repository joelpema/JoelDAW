import { Component } from '@angular/core';

@Component({
  selector: 'app-card-user',
  imports: [],
  templateUrl: './card-user.html',
  styleUrl: './card-user.css',
})
export class CardUser {

}
