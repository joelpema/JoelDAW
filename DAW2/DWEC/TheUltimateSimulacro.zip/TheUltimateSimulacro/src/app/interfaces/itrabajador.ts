export interface Itrabajador {
}
