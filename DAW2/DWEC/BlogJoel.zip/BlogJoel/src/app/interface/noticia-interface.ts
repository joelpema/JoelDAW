export interface NoticiaInterface {

    title: string,
    image: string,
    text: string,
    fecha: Date
}
