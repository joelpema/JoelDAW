

export const data = {
        currency: "€",
        products: [
        {
        SKU: "",
        title: "",
        price: ""
        },

        {
        SKU: "",
        title: "",
        price: ""
        },

        {
        SKU: "",
        title: "",
        price: ""
        }
        
    ]
}




