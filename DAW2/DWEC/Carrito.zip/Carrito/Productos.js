

export default class Productos {



    constructor(SKU, titulo, precio){
        this.SKU = SKU;
        this.titulo = titulo;
        this.precio = parseFloat(precio);
    }
}


